import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

//This is the class declaration and it implements ActionListeners
public class Main implements ActionListener {

    //These are all the objects and variables that are added
    JFrame frame;
    JTextField textField;
    JButton[] numberButtons = new JButton[10];
    JButton[] functionButtons = new JButton[9];
    JButton addButton,subButton,mulButton,divButton;
    JButton decButton, equButton, delButton, clrButton, negButton;
    JPanel panel;

    //This sets it to default font
    Font myFont = new Font("",Font.BOLD,30);


    double num1=0,num2=0,result=0;
    char operator;

    //This is the main constructor which creates the frame and everything in it
    Main(){
        //This sets the frame object its height and width and how it closes
        frame = new JFrame("Calc");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(420,550);
        frame.setLayout(null);

        //This sets the text field on the frame which stores the visuals for the numbers and answers
        textField = new JTextField();
        textField.setBounds(50, 25, 300, 50);
        textField.setFont(myFont);
        textField.setEditable(false);

        //This initiates all the JBttons
        addButton = new JButton("+");
        subButton = new JButton("-");
        mulButton = new JButton("*");
        divButton = new JButton("/");
        decButton = new JButton(".");
        equButton = new JButton("=");
        delButton = new JButton("Del");
        clrButton = new JButton("Clr");
        negButton = new JButton("(-)");

        //This set which point each button is in the array
        functionButtons[0] = addButton;
        functionButtons[1] = subButton;
        functionButtons[2] = mulButton;
        functionButtons[3] = divButton;
        functionButtons[4] = decButton;
        functionButtons[5] = equButton;
        functionButtons[6] = delButton;
        functionButtons[7] = clrButton;
        functionButtons[8] = negButton;

        //This adds each functionButton to the actionListener and the font
        for(int i = 0; i<8; i++) {
            functionButtons[i].addActionListener(this);
            functionButtons[i].setFont(myFont);
            functionButtons[i].setFocusable(false);
        }

        //This initiates the numberButtons using a for loop for number below 10 and adds it to the action listener
        for(int i =0; i<10; i++) {
            numberButtons[i] = new JButton(String.valueOf(i));
            numberButtons[i].addActionListener(this);
            numberButtons[i].setFont(myFont);
            numberButtons[i].setFocusable(false);
        }

        //This set the location for the neg, del and clr buttons on the frame
        negButton.setBounds(50,430,100,50);
        delButton.setBounds(150,430,100,50);
        clrButton.setBounds(250,430,100,50);

        //This creates the JPanel and where it is located also the grid that it follows and color
        panel = new JPanel();
        panel.setBounds(50, 100, 300, 300);
        panel.setLayout(new GridLayout(4,4,10,10));
        panel.setBackground(Color.BLUE);

        //This adds all the numberButtons and the rest of the functionButton on the panel grid
        panel.add(numberButtons[1]);
        panel.add(numberButtons[2]);
        panel.add(numberButtons[3]);
        panel.add(addButton);
        panel.add(numberButtons[4]);
        panel.add(numberButtons[5]);
        panel.add(numberButtons[6]);
        panel.add(subButton);
        panel.add(numberButtons[7]);
        panel.add(numberButtons[8]);
        panel.add(numberButtons[9]);
        panel.add(mulButton);
        panel.add(decButton);
        panel.add(numberButtons[0]);
        panel.add(equButton);
        panel.add(divButton);


        //This adds the panel,negButton,delButton,clrButton and the textField to the frame and sets it visible
        frame.add(panel);
        frame.add(negButton);
        frame.add(delButton);
        frame.add(clrButton);
        frame.add(textField);
        frame.setVisible(true);
    }

    //This is the main method which creates the main object running the constructor
    public static void main(String[] args) {
        Main c = new Main();
    }

    //This performs all the actions that the buttons make.
    @Override
    public void actionPerformed(ActionEvent e) {

        //Creates all the number values and turn them into a string value for the textField
        for(int i=0; i<10; i++) {
            if(e.getSource() == numberButtons[i]){
                textField.setText(textField.getText().concat(String.valueOf(i)));
            }
        }
        //This sets the decButton to add a decimal point in the text field
        if(e.getSource()==decButton){
            textField.setText(textField.getText().concat("."));
        }
        //This sets the addButtons operator to a '+' and sets it to the textField
        if(e.getSource()==addButton){
            num1 = Double.parseDouble(textField.getText());
            operator = '+';
            textField.setText("");
        }
        //This sets the subButton operator to a '-' and set it to the textField
        if(e.getSource()==subButton){
            num1 = Double.parseDouble(textField.getText());
            operator = '-';
            textField.setText("");
        }
        //This sets the mulButton operator to a '*' and set it to the textField
        if(e.getSource()==mulButton){
            num1 = Double.parseDouble(textField.getText());
            operator = '*';
            textField.setText("");
        }
        //This sets the dicButton operator to a '/' and set it to the textField
        if(e.getSource()==divButton){
            num1 = Double.parseDouble(textField.getText());
            operator = '/';
            textField.setText("");
        }
        //This sets the equButton and makes it complete the equation for each type of operator and show the result
        if(e.getSource()==equButton) {
            num2=Double.parseDouble(textField.getText());

                switch(operator) {
                     case '+':
                         result = num1 + num2;
                         break;
                     case '-':
                         result = num1 - num2;
                         break;
                    case '*':
                        result = num1 * num2;
                        break;
                    case '/':
                        result = num1 / num2;
                        break;
                }
                textField.setText(String.valueOf(result));
                num1=result;
            }

        //This sets the clr button and makes the text field clear
        if(e.getSource()==clrButton){
            textField.setText("");
        }

        //This sets the del button and make the first value be deleted on the textField
        if(e.getSource()==delButton){
            String s = textField.getText();
            textField.setText("");
            for(int i=0; i<s.length(); i++){
                textField.setText(textField.getText()+s.charAt(i));
            }
        }

        //This adds the function to the negButton which makes the numbers negative by multiplying them by -1
        if(e.getSource()==negButton){
            double temp = Double.parseDouble(textField.getText());
            temp*=-1;
            textField.setText(String.valueOf(temp));
        }
    }
}